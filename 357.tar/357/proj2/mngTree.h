/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Header file.
 *
 * Last Modified: Fri Jan 28 22:25:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */
#ifndef MNGTREE_H
#define MNGTREE_H

#define SUCCESS                      0
#define CANNOT_MALLOC_WORDARRAY      1
#define NO_WORDS_ON_INPUT            2
#define NO_MEMORY_FOR_WORDNODE       3
#define NO_MEMORY_FOR_WORD           4
#define NONALPHA "1234567890 \v\f\n\t\r+=-*/\\,.;:'#~?<>|{}[]`!\"£$%^&()"

typedef struct WORD
{
  char *Word;
  size_t Count;
  struct WORD *Left;
  struct WORD *Right;
} WORD;

int read_input_to_tree(WORD **DestTree, size_t *Treecount, FILE *Input);
int add_to_tree(WORD **DestTree, size_t *Treecount, char *Word); 
int walk_tree(WORD **DestArray, WORD *Word);
void free_tree(WORD *W);
char *dupstr(char *s);

#endif

/* vim: set et ai sts=2 sw=2: */
