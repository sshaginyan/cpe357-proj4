/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Program "describe the program here (without quotes)"
 *
 * Last Modified: Fri Jan 28 23:39:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "mngTree.h"
#include "print.h"


int top_words;

/** The main thing.
 * @param argc the number of tokens on the input line.
 * @param argv an array of tokens.
 * @return 0 on success, 1-255 on failure
 */
int
main(int argc, char *argv[])
{ 
  int Status = SUCCESS;
  WORD *Words = NULL;
  size_t Treecount = 0;
  WORD **WordArray = NULL;
  FILE *p_file;
  int index = 2;

  top_words = atoi(argv[1]);

  if(SUCCESS == Status)
  {
    if(argv[2] == NULL)
      Status = read_input_to_tree(&Words, &Treecount, stdin);
    else
    {
      if(strcmp(argv[index],"-n") == 0)
        if(argv[index+1] != NULL)
          top_words = atoi(argv[index+1]);
          
      if((p_file = fopen(argv[2], "r")) == NULL)
        /* print error if no file is found */
        perror(argv[index-1]);
      else
        Status = read_input_to_tree(&Words, &Treecount, p_file);
    }
  }

  /* check to see if there was input */
  if(SUCCESS == Status)
  {
    /* if treecount is zero then no word was entered */
    if(0 == Treecount)
    {
      Status = NO_WORDS_ON_INPUT;
    }
  }

  /* if the input was successful */
  if(SUCCESS == Status)
  {
    /* allocate enough space for the word array */
    WordArray = malloc(Treecount * sizeof *WordArray);

    /* if the word array is empty than size of array wasn't successfull */
    if(NULL == WordArray)
    {
      Status = CANNOT_MALLOC_WORDARRAY;
    }
  }

  /* Traverse the tree into the array */
  if(SUCCESS == Status)
  {
    Status = walk_tree(WordArray, Words);
  }

  /* qsort the array */
  if(SUCCESS == Status)
  {
    qsort(WordArray, Treecount, sizeof *WordArray, compare_counts);
  }

  /* traverse the WordArray outputting the values */
  if(SUCCESS == Status)
  {
    Status = output_words(stdout, Treecount, WordArray);
  }

  /* free the word array */
  if(NULL != WordArray)
  {
    free(WordArray);
    WordArray = NULL;
  }

  /* free the tree memory */
  if(NULL != Words)
  {
    free_tree(Words);
    Words = NULL;
  }

  /* if the success value is not equal to the current satus print message */
/*  if(SUCCESS != Status)
  {
    printf("The top 10 words (out of 0) are:\n");    
  }
*/  
  return (SUCCESS == Status ? EXIT_SUCCESS : EXIT_FAILURE);

}

/* vim: set et ai sts=2 sw=2: */
