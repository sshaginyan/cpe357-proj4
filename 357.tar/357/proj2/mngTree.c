/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 * 
 * This file contains functions to manage (read/write/traverse/clean)
 * tree structure.
 *
 * Last Modified: Fri Jan 28 22:20:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "mngTree.h"

/** Function to free the tree.
 * @param W pointer to WORD.
 */
void free_tree(WORD *W)
{
  if(NULL != W)
  {
    if(NULL != W->Word)
    {
      /*free the pointer to the member of structure */
      free(W->Word);
      W->Word = NULL;
    }
    if(NULL != W->Left)
    {
      /* free the pointer to the member of sturcture Left */
      free_tree(W->Left);
      W->Left = NULL;
    }
    if(NULL != W->Right)
    {
      /* free the pointer to the member of sturcture Right */
      free_tree(W->Right);
      W->Right = NULL;
    }
  }
}

/** Function adds words to the binary tree.
 * @param DestTree
 * @param Treecount
 * @param Word
 * @return Status code 
 */
int add_to_tree(WORD **DestTree, size_t *Treecount, char *Word)
{
  int Status = SUCCESS;
  int CompResult = 0;

  /* safety check */
  assert(NULL != DestTree);
  assert(NULL != Treecount);
  assert(NULL != Word);

  /* if *DestTree is NULL then add to the tree */
  if(NULL == *DestTree)
  {
    /*allocate memory for the destination tree */
    *DestTree = malloc(sizeof **DestTree);
    
    /* check the memory allocated for the destination tree */
    if(NULL == *DestTree) 
    {
      /* set status to 3 if there is no more memory */
      Status = NO_MEMORY_FOR_WORDNODE;
    }
    else
    {
      (*DestTree)->Left = NULL;
      (*DestTree)->Right = NULL;
      (*DestTree)->Count = 1;
      (*DestTree)->Word = dupstr(Word);
      
      /* if the DestTree pointer which points to member of the structure
       * is equall to null */
      if(NULL == (*DestTree)->Word)
      {
        /* we've run out of memory in the middle so set status to 4*/
        Status = NO_MEMORY_FOR_WORD; 
        
        /*free the pointer DestTree */
        free(*DestTree);
        *DestTree = NULL;
      }
      else
      {
        /* add one to the tree nodes count */
        ++*Treecount;
      }
    }
  }
  else
    /* we need to make a decision by computing the result */
  {
    CompResult = strcmp(Word, (*DestTree)->Word);
    if(0 < CompResult)
    {
      Status = add_to_tree(&(*DestTree)->Left, Treecount, Word);
    }
    else if(0 > CompResult)
    {
      Status = add_to_tree(&(*DestTree)->Left, Treecount, Word);
    }
    else
    {
      /* add one to the count - this is the same node */
      ++(*DestTree)->Count;
    }
  }
  return Status;  
}

/** Function reads file input to be entered into tree.
 * @param DestTree
 * @param Treecount
 * @param Input
 * @return Status code 
 */
int read_input_to_tree(WORD **DestTree, size_t *Treecount, FILE *Input)
{
  int Status = SUCCESS;
  char Buf[8192] = {0};
  char *Word = NULL;

  /* safety check */
  assert(NULL != DestTree);
  assert(NULL != Treecount);
  assert(NULL != Input);

  /* while loop to get the words from each line */
  while(NULL != fgets(Buf, sizeof Buf, Input))
  {    
    int i;
    int len = strlen(Buf);

    for(i = 0; i<len; i++)
    {
      Buf[i] = tolower(Buf[i]);
    }

    /* strtok the input to get only alpha character without the delimiters*/
    Word = strtok(Buf, NONALPHA);
    
    while(SUCCESS == Status && NULL != Word)
    {
      /* add the word to the tree */
      Status = add_to_tree(DestTree, Treecount, Word); 

      /* next word */
      if(SUCCESS == Status) 
      {
        Word = strtok(NULL, NONALPHA);
      }
    }
  }
  return Status;
}

/** Function that traverses the tree.
 * @param DestArray
 * @param Word
 * @return Status code
 */
int walk_tree(WORD **DestArray, WORD *Word)
{
  int Status = SUCCESS;
  static WORD **Write = NULL;
  
  /* safety check */
  assert(NULL != Word);

  /* store the starting point if this is the first call */
  if(NULL != DestArray)
  {
    Write = DestArray;
  }

  /* add this node and it's children */
  if(NULL != Word)
  {
    *Write = Word;
    ++Write;
    if(NULL != Word->Left)
    {
      Status = walk_tree(NULL, Word->Left);
    }
    if(NULL != Word->Right)
    {
      Status = walk_tree(NULL, Word->Right);
    }
  }
  return Status;
}

/** Function to duplicate a string.
 * @param s
 * @return duplicated string
 */
char *dupstr(char *s)
{
  char *Result = NULL;
  size_t slen = 0;
  
  /* sanity check */
  assert(NULL != s);

  /* get string length */
  slen = strlen(s);
  
  /* allocate enough storage */
  Result = malloc(slen + 1);
 
  /* make the string copy */
  if(NULL != Result)
  {
    memcpy(Result, s, slen);
    *(Result + slen) = '\0';
  }
  return Result;
}
/* vim: set et ai sts=2 sw=2: */
