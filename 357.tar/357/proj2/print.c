/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Functions to print the output to the terminal.
 *
 * Last Modified: Fri Jan 29 22:39:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <assert.h>
#include "mngTree.h"

extern int top_words;

/** Function compares word items.
 * @param vWord1
 * @param vWord2
 * @return Result 1 if match, -1 if not a match
 */
int compare_counts(const void *vWord1, const void *vWord2)
{
  int Result = 0;
  WORD * const *Word1 = vWord1;
  WORD * const *Word2 = vWord2;
 
  assert(NULL != vWord1); 
  assert(NULL != vWord2); 

  /* ensure the result is either 1, 0 or -1 */
  if((*Word1)->Count < (*Word2)->Count)
  {
    Result = 1;
  }
  else if((*Word1)->Count > (*Word2)->Count)
  {
    Result = -1;
  }
  else
  {
    if(strcmp((*Word1)->Word, (*Word2)->Word ) < 0)
      Result = 1;
    else if(strcmp((*Word1)->Word, (*Word2)->Word ) > 0)
      Result = -1;
    else
      Result = 0;
  }
  return Result;
}

/** Function to output the frequency of a word
 * @param Dest
 * @param Count
 * @param WordArray
 * @return Status
 */
int output_words(FILE *Dest, size_t Count, WORD **WordArray)
{
  int Status = SUCCESS;
  size_t Pos = top_words - 1;
 
  /* safety check */
  assert(NULL != Dest);
  assert(NULL != WordArray);

  fprintf(Dest,"The %i most frequent words are:\n",top_words); 

  /* Print the words in descending order */
  if(Count < top_words)
    top_words = Count;

  while(SUCCESS == Status && Pos < top_words) 
  {
    fprintf(Dest, "%20s %d\n", WordArray[Pos]->Word,
        (int)WordArray[Pos]->Count);
    --Pos;
  }
  return Status;
}

/* vim: set et ai sts=2 sw=2: */
