/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Header file.
 *
 * Last Modified: Fri Jan 28 22:25:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */
#ifndef PRINT_H
#define PRINT_H

int compare_counts(const void *vWord1, const void *vWord2);
int output_words(FILE *Dest, size_t Count, WORD **WordArray);

#endif

/* vim: set et ai sts=2 sw=2: */
