/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Program "describe the program here (without quotes)"
 *
 * Last Modified: Wed Jan 05 13:39:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

#define CR  (int) '\r'
#define LF  (int) '\n'
#define NL  (int) '\n'

/** The main thing.
 * @param argc the number of tokens on the input line.
 * @param argv an array of tokens.
 * @return 0 on success, 1-255 on failure
 */
int
main(int argc, char *argv[])
{
  int prev_c;
  int c;
  FILE *in_file;
  FILE *out_file;

  if ((in_file = fopen(argv[1], "r")) == NULL)
  {
    printf("Couldn't open \"%s\" for reading\n", argv[1]);
    return EXIT_FAILURE;
  }
  if (argc < 3)
  {
    printf("Did not indicate output file\n");
    return EXIT_FAILURE;
  }

/*  fprintf(out_file, "There are %d things on the command line\n", argc);
  fprintf(out_file, "The program name is \"%s\"\n", argv[0]);

  fprintf(out_file, "The arguments are:\n");

  for(i = 1; i < argc; i++)
  {
    fprintf(out_file, "  %s\n", argv[i]);
  }*/

  prev_c = fgetc(in_file);
  
  if (prev_c  == EOF)
  {
    printf("Empty input file \"%s\"\n", argv[1]);
    return EXIT_FAILURE;
  }

  out_file = fopen(argv[2], "w");

  c = fgetc(in_file);

  while(c != EOF)
  {
    if ((prev_c == CR) && (c == LF))
    {
      fputc(NL, out_file);
    }
    else
      fputc(prev_c, out_file);
    
    prev_c = c;
  }

  fclose(in_file);
  fclose(out_file);
  return EXIT_SUCCESS;
}

/* vim: set et ai sts=2 sw=2: */
