/**
 * @file
 * Functions for encoding/decoding ROT13 code.
 * <pre> CPE 357 Winter 2011
 * Last Modified: Tue Feb 08 19:27:48 PST 2011</pre>
 * @author Luis Castillo
 */

#include "rot13.h"

/**
 * Turn a character into the equivalent ROT13 code character.
 * @param c the character to encode.
 * @return a pointer to the ROT13 code for the character.
 */
char toROT13(char c) {
  if ((c >= 'A' && c <= 'M') || (c >= 'a' && c <= 'm'))
    return (c + 13);
  else if ((c >= 'N' && c <= 'Z') || (c >= 'n' && c <= 'z'))
    return (c - 13);
  else
    return c;
}

/* vim: set et ai sts=2 sw=2: */
