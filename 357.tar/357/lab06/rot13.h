/**
 * @file
 * Header for functions for encoding/decoding ROT13 code.
 * <pre> CPE 357 Winter 2011
 * Last Modified: Tue Feb 08 19:25:44 PST 2011</pre>
 * @author Luis Castillo
 */

#ifndef ROT13_H
#define ROT13_H

#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

#include <termios.h>

#include <stdio.h>
#include <string.h>
#include <ctype.h>

/** Transcribe an ASCII char to a morse string. */
char toROT13(char c);

/**
 * \def TOKENLEN
 * the maximum size of a token.  Actually
 * 7 should do it (and detect any overlong tokens) because
 * no defined code sequence has more than 6 dits and dahs.
 */
#define TOKENLEN 10

#endif
