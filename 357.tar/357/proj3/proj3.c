/**
 * @file
 * Functions for huffman encoding/decoding.
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Functions for huffman encoding/decoding.
 *
 * Last Modified: Wed Feb 09 20:43:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include "proj3.h"

/** This function creates a linked list
 * sorted by count of characters.
 * @param array pointer to array
 * @param n number of unique characters read
 * @return pointer to linked list
 */
node *makeList(node *array, int n)
{
  int i;
  node *head, *ptr;

  head->code = EOF;
  head->count = 1;
  head->left = (node*)NULL;
  head->right = (node*)NULL;
  ptr = head;
  
  for (i = N_CHARS - n; i < N_CHARS; i++)
  {
    ptr->next = (node*)malloc(sizeof(node));
    ptr = ptr->next;
    ptr->code = array[i].code;
    ptr->count = array[i].count;
    ptr->left = (node*)NULL;
    ptr->right = (node*)NULL;
  }
  return head;
}

/** This funtion generates the binary tree
 * @param head pointer to the linked list
 * @return a pointer to the root of the tree
 */
node *build_binary_tree(node *head)
{int i=1;
  while(head->next)
  {
    printf("will create node #%d\n", i);
    head = combine_nodes(head);
    i++;
  }
  return head;
}

/** This function combines the first two 
 * nodes on the list and constructs a new node
 * @param ptr pointer to what will be the left node
 * @return pointer to the head node of the list
 */
node *combine_nodes(node *ptr)
{
  node *new ;
  if(!(new = malloc(sizeof(node))))
    exit(1);
  
  new->code = -1;
  new->left = ptr;
  new->right = ptr->next;
  new->count = ptr->count + ptr->next->count;

  ptr = insert_new_node(ptr->next->next, new); 

  return ptr;
}

/** This function inserts new node to the list
 * if count is greater than count of head
 * @param head pointer to head of the list
 * @param new pointer to node to be inserted
 * @return pointer to the head of the list
 */
node *insert_new_node(node *head, node *new)
{
  node *ptr;

  ptr = head;

  if(ptr == NULL)
    return new;
  else if((new->count < head->count) || (new->count == head->count))
  {
    new->next = head;
    head = new;
    return head;
  }
  else 
    while(ptr->next)
    {
      if((new->count < ptr->next->count) || (new->count == ptr->next->count))
      {
        new->next = ptr->next;
        ptr->next = new;
        return head;
      }
      else
        ptr = ptr->next;
    }

  if(!ptr->next)
  {
    ptr->next = new;
    ptr->next->next = (node*)NULL;
  }
  return head;  
}

/** This function gets the binary code for the character
 * @param head pointer to the root of the tree
 * @return pointer to path to each character
 */
char **getPath(struct node *head)
{
  char *outputstr;
  char *pathArray[N_CHARS];
 
  if(head->left)
  {
    outputstr =  strcat(outputstr, "0");
    pathArray = getPath(head->left,outputstr,pathArray);
    outputstr[strlen(outputstr) - 1] = '\0';
    
    
    outputstr = strcat(outputstr,"1");
    pathArray = getPath(head->right,outputstr,pathArray);
    outputstr[strlen(outputstr) - 1] = '\0';
  }
  else
  {
    pathArray[head->code] = malloc(N_CHARS);
    strcpy(pathArray[head->code], outputstr);
  }
  return pathArray;
}

/** This function prints the binary tree
 * for debugging purposes.
 * @param n pointer to root of tree
 */
void printTree(node *n)
{
  if (n->left)
    printTree(n->left);
  printf("code %c ", (char)n->code);
  printf("count %d\n", n->count);
  if (n->right)
    printTree(n->right);
}

/* vim: set et ai sts=2 sw=2: */                                             


