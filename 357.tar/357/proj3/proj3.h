/**
 * @file
 * Header for functions for Huffman encoding/decoding.
 * <pre> CPE 357 Winter 2011
 * Last Modified: Tue Feb 08 19:25:44 PST 2011</pre>
 * @author Luis Castillo
 */

#ifndef PROJ3_H
#define PROJ3_H

#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <ctype.h>

#define N_CHARS 256

typedef struct node
{
  int code;
  int count;
  struct node *next;
  struct node *left;
  struct node *right;
}node;

/* Function prototypes */
node *read_file(int);
node *makeList(node *array, int);
node *build_binary_tree(node *);
node *combine_nodes(node *);
node *insert_new_node(node *, node *);
char **getPath(node *head, char *outputstr, char*parthArray[N_CHARS]);
void printTree(node*);
#endif
