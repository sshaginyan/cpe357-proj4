/**
 * @file
 * Program compresses input file using huffman encoding
 * method.
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * This program compresses input file using the Huffman
 * encoding method.
 *
 * Last Modified: Tue Feb 08 21:22:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

#include "proj3.h"

/** The main thing.
 * @param argc the number of tokens on the input line.
 * @param argv an array of tokens.
 * @return 0 on success, 1-255 on failure
 */
int
main(int argc, char *argv[])
{
  int fd_in;
  int fd_out;
  node *list;
  node *tree;
   
  if (argc < 2)
  {
    perror("usage: proj3e infile [outfile]");
    exit(EXIT_FAILURE);
  }

  if ((fd_in = open(argv[1], O_RDONLY)) == -1)
  {
    perror(argv[1]);
    exit(EXIT_FAILURE);
  }

  if (argc == 3)
  {
    if ((fd_out = open(argv[2], O_RDWR | O_CREAT, S_IRWXU)) == -1)
    {
      perror(argv[2]);
      exit(EXIT_FAILURE);
    }
  }
  else if (argc == 2)
    fd_out = STDOUT_FILENO;

  list = read_file(fd_in);

  tree = build_binary_tree(list);
  
 /* getPath(ptr, path, pathArray);

   print header 
  write(fd_out, &n_uniq_chars, sizeof(int));
  for(i = 0; i < N_CHARS; i++)
  {
    if(array[i].count != 0)
    {
      write(fd_out,&i,sizeof(char));
      write(fd_out,&array[i],sizeof(int));
    }
  }
  lseek(fd_in, 0, SEEK_SET);
  while(1)
  {
//     reading in the bytes into the buffer //
    bytes_read = read(fd_in,buff,N_CHARS);
    if(bytes_read < 0)
      perror("error");
    else if(bytes_read == 0)
    {
      close(fd_in);
      break;
    }
    else if(bytes_read > 0)
    {
      shift = 7;
      for(i = 0; i < bytes_read; i++)
      {
        len = strlen(pathArray[buff[i]]);
        for(j = 0; j < len; j++)
        {
          if(pathArray[buff[i]][j] == '1')
          {
            byte |= 1;
          }
          byte <<= 1;
          shift--;
          if(shift == 0)
          {
            write(fd_out, &byte, sizeof(char));
            shift = 7; 
            byte = 0;
          }
        }
      } 
    }
  }
  if(shift == 0)
  {
    write(fd_out, &byte, sizeof(char));
    shift = 7; 
    byte = 0;
  }                                           */

  return EXIT_SUCCESS;
}

/** Compares a pair of elements. Called by qsort()
 * @param a pointer to first element to be compared
 * @param b pointer to second element to be compared
 * @returns a number less than, equal to, or greater
 * than 0 if the first element is less than, equal to,
 * or greater than the second element.
 */
int compare(const void *a, const void *b)
{
  node *ia = (node *)a;
  node *ib = (node *)b;
  return (int)(ia->count - ib->count);
}

/** This function reads the characters from the input
 * file and counts their frequency in the file.
 * Creates a sorted linked list with the characters
 * and frequencies.
 * @param fd_in file descriptor to input file
 * @return pointer to head of linked list
 */
node *read_file(int fd_in)
{
  int chars_read = 0;
  unsigned char buff[N_CHARS];
  node array[N_CHARS];
  int n_uniq_chars = 0;
  node *ptr;
  int i;

  for (i = 0; i < N_CHARS; i++)
  {
    array[i].code = 0;
    array[i].count = 0;
  }

  while(1)
  {
    chars_read = read(fd_in, buff, N_CHARS);
    if (chars_read == -1)
    {
      perror("error reading file");
      exit(EXIT_FAILURE);                    
    }
    else if (chars_read > 0)
      for (i = 0; i < chars_read; i++)
      {
        if(buff[i] > -1 && buff[i] < N_CHARS && array[(int)buff[i]].count == 0)
        {
          n_uniq_chars++;
          array[(int)buff[i]].code = (int)buff[i];
          array[(int)buff[i]].count++;
        }
        else
          array[(int)buff[i]].count++;
      }
    else if (chars_read == 0)
    {
      close(fd_in);
      break;
    }
  }
  
  qsort(array, N_CHARS, sizeof(node), compare);

  ptr = makeList(array, n_uniq_chars);

  return ptr;
}

/* vim: set et ai sts=2 sw=2: */
