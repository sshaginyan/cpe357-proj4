/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Program does very little but go to sleep. It catches
 * signals and displays message "I'm sleeping" then
 * returns to sleep.
 *
 * Last Modified: Wed Feb 16 20:55:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <signal.h>

/* function prototype */
void handler(int);

/** The main thing.
 * @param argc the number of tokens on the input line.
 * @param argv an array of tokens.
 * @return 0 on success, 1-255 on failure
 */
int
main(int argc, char *argv[])
{
  (void) signal(SIGHUP,  handler); 
  (void) signal(SIGINT, handler); 
  (void) signal(SIGQUIT, handler); 
  (void) signal(SIGILL,  handler); 
  (void) signal(SIGABRT, handler); 
  (void) signal(SIGFPE,  handler); 
  (void) signal(SIGSEGV, handler); 
  (void) signal(SIGPIPE, handler); 
  (void) signal(SIGALRM, handler); 
  (void) signal(SIGTERM, handler); 
  (void) signal(SIGUSR1, handler); 
  (void) signal(SIGUSR2, handler); 
  (void) signal(SIGCHLD, handler); 
  (void) signal(SIGCONT, handler); 
  (void) signal(SIGTSTP, handler); 
  (void) signal(SIGTTIN, handler); 
  (void) signal(SIGTTOU, handler); 
  (void) signal(SIGTRAP, handler); 

  while(1)
    sleep(1);

  /* should never reach this */
  return EXIT_SUCCESS;
}

void handler (int sig)
{
  printf("I'm sleeping\n");
}

/* vim: set et ai sts=2 sw=2: */
