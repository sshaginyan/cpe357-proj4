/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Program "describe the program here (without quotes)"
 *
 * Last Modified: Wed Jan 29 13:39:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>
#include <sys/param.h> 

/** The main thing.
 * @param argc the number of tokens on the input line.
 * @param argv an array of tokens.
 * @return 0 on success, 1-255 on failure
 */
int
main(int argc, char *argv[])
{
  int a = 0;
  int b = 0;
  char path[MAXPATHLEN];
  getcwd(path, MAXPATHLEN);
  printf("pwd -> %s\n", path);

  a = isascii(055);
  b = isascii(0404);

  printf("ascii %d non-ascii %d\n", a, b);

  return EXIT_SUCCESS;
}

/* vim: set et ai sts=2 sw=2: */
