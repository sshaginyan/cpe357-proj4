/**
 * @mystrstr.c
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * This program implementes the same functionality as strstr,
 * and returns the location in the string where the substring
 * is located.
 *
 * Last Modified: Fri Jan 15 13:46:00 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h>

char *mystrstr(char *haystack, char *needle)
{
  int i, j, k; /* loop variables */
  int len; /* substring length variable */
  int count = 0;
  char *pi;

  /* obtains length of the substring needle and
   * stores it in variable len */
  for(len = 0; *(needle + len) != '\0'; len++);

  /* goes through each location in the haystack */  
  for(i = 0; *(haystack + i) != '\0'; i++)
  {
    /* if string in needle equals string in haystack */
    if(*(haystack + i) == *needle)
    {
      for(j = i, k = 0; *(needle + k) != '\0'; j++, k++)
      {
        /* compare each character in needle with each
         * each charater in haystack to make sure the
         * entire needle is found in the haystack */
        if(*(haystack + j) == *(needle + k))
          count++;
        else
          count = 0;
        /* after checking that the entire needle is
         * found in the haystack, return initial position */
        if(count == len)
        {
          pi = (char*) malloc(sizeof(char*));
          *pi = i;
          return pi;
        }
      }
    }
  }
  return NULL;
}

/* vim: set et ai sts=2 sw=2: */
