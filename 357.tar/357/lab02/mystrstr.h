/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Program "describe the program here (without quotes)"
 *
 * Last Modified: Wed Oct 29 13:39:06 PDT 2008</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */
#ifndef MYSTRSTR_H
#define MYSTRSTR_H

char *mystrstr(char *haystack, char *needle);

#endif
/* vim: set et ai sts=2 sw=2: */
