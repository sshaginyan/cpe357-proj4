/**
 * @strfind.c
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * This program prompts the used to enter a string and
 * a substring. Then it call mystrstr to find the location
 * where the substring appears in the string.
 *
 * Last Modified: Fri Jan 14 13:48:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <ctype.h>

#include "mystrstr.h"

int main()
{
  /* variable declaration */
  char haystack[200];
  char needle[200];
  char new_needle[200];
  char *found;
  int chk = 0;
  int index = 0;
  int i;

  /* loops until ctrl-D is pressed */
  while(chk == 0)
  {
    /* initialize arrays */
    for(i = 0; i < 200; i++)
    {
      haystack[i] = '\0';
      needle[i] = '\0';
      new_needle[i] = '\0';
    }
 
    /* prompt for haystack string */
    printf("Enter a string: ");
    fgets(haystack, sizeof(haystack), stdin);

    /* if ctrl-D force exit */
    if(feof(stdin))
    {
      printf("\nGood bye.\n");
      chk = 1;
      return 0;
    }

    /* prompt for needle string */
    printf("Enter a possible substring: ");
    fgets(needle, sizeof(needle), stdin);

    /* remove NL character due to fgets */
    while(needle[index] != '\n')
    {
      new_needle[index] = needle[index];
      index++;
    }
    new_needle[index] = '\0';
    index = 0;

    /* calls mystrstr and stores returned
     * value in variable found */
    found = mystrstr(haystack, new_needle);

    /* if needle found or not, output
     * message accordingly */
    if(found != NULL)
      printf("The substring occurs at position %d\n\n", *found);
    else
      printf("No substring found.\n\n");
  }
  return EXIT_SUCCESS;
}

/* vim: set et ai sts=2 sw=2: */
