/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Program "describe the program here (without quotes)"
 *
 * Last Modified: Wed Jan 29 13:39:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>

#include "debug.h"

/** @def BUFL
 * The buffer size to use. This one is really small.
 */
#define BUFL 102

#undef DEBUG
#define DEBUG

void find_box(char b_n[]);

int fd;
char buf[BUFL];
/** The main thing.
 * @return 0 on success, 1-255 on failure
 */
int
main(void)
{
  char box_num[10];
  char p[10];
  int box_n;
  char *end_p;
  int index = 0;

  if((fd = open("boxes.rec", O_RDWR | O_CREAT, S_IRWXU)) == -1)
  {
    perror("open");
    exit(EXIT_FAILURE);
  }

  while(1)
  {
    printf("Enter box number: ");
    fgets(box_num, sizeof(box_num), stdin);

    while(box_num[index] != '\n')
    {
      p[index] = box_num[index];
      index++;
    }
    p[index] = '\0';
    index = 0;

    box_n = strtol(p, &end_p, 10);

    if(*end_p != '\0' || box_n < 0)
    {
      fprintf(stderr, "Invalid box number.\n");
      exit(EXIT_FAILURE);
    }
    else
    {
      printf("will loop again.\n");
      find_box(p);
    }
  }

/*  x = read(fd, buf, BUFL);*/

  printf("Box number entered: %d\n", box_n);
  printf("%s\n",buf); 
  return EXIT_SUCCESS;
}

void find_box(char b_n[])
{
  int off_s = 0;
  printf("will search for box. %s\n", b_n);
  off_s = read(fd, buf, BUFL);
  printf("read this # of bytes. %d\n", off_s);
  


  

}

/* vim: set et ai sts=2 sw=2: */
