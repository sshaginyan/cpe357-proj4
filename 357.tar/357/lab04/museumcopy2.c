/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Program "describe the program here (without quotes)"
 *
 * Last Modified: Wed Jan 29 13:39:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>

#include "debug.h"

/** @def BUFL
 * The buffer size to use. This one is really small.
 */
#define BUFL 102

#undef DEBUG
#define DEBUG
struct index_card
{
  int box_no;
  int *file_addr;
}; 

void find_box(int);
void AddToRoledex(struct index_card);

struct index_card *roledex = NULL;
int num_elements = 0;
int num_allocated = 0;
int fd;
char buf[BUFL];
/** The main thing.
 * @return 0 on success, 1-255 on failure
 */
int
main(void)
{
  char box_num[10];
  char p[10];
  int box_n;
  char *end_p;
  int index = 0;

  while(1)
  {
    printf("Enter box number: ");
    fgets(box_num, sizeof(box_num), stdin);

    while(box_num[index] != '\n')
    {
      p[index] = box_num[index];
      index++;
    }
    p[index] = '\0';
    index = 0;

    box_n = strtol(p, &end_p, 10);

    if(*end_p != '\0' || box_n < 0)
    {
      fprintf(stderr, "Invalid box number.\n");
      exit(EXIT_FAILURE);
    }
    else
    {
      printf("will loop again.\n");
      find_box(box_n);
    }
  }

  /*  x = read(fd, buf, BUFL);

      printf("Box number entered: %d\n", box_n);
      printf("%s\n",buf);   */
  return EXIT_SUCCESS;
}

void find_box(int b_n)
{
  struct index_card item;
  /*  int off_s = 0;*/
  printf("Searching for box #: %d\n", b_n);
  if (num_elements == 0)
  {
    if((fd = open("boxes.rec", O_RDWR | O_CREAT, S_IRWXU)) == -1)
    {
      perror("open");
      exit(EXIT_FAILURE);
    }
    item.box_no = b_n;
    item.file_addr = (int*)fdopen(fd, "a");
    AddToRoledex(item);
  }
  else
  {
    perror("roledex");
    exit(EXIT_SUCCESS);    
  }
}

void AddToRoledex(struct index_card item)
{
  void *_tmp;
  if (num_elements == num_allocated)
  {
    if (num_allocated == 0)
      num_allocated = 3;
    else
      num_allocated *= 2;

    _tmp = realloc(roledex, (num_allocated * sizeof(struct index_card)));

    if (!_tmp)
    {
      fprintf(stderr, "ERROR: Couldn't realloc memory!\n");
      exit(EXIT_FAILURE);
    }
    roledex = (struct index_card*)_tmp;
  }
  roledex[num_elements] = item;
  printf("Added new box number\n");
  num_elements++;
}

/* vim: set et ai sts=2 sw=2: */

