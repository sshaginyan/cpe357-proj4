/**
 * @file
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * This program looks for a box number and allows to read and
 * overwrite/delete the contents of that box in file boxes.rec
 *
 * Last Modified: Fri Jan 28 16:39:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#include <string.h>
#include <ctype.h>
#include <errno.h>
#include <limits.h>

/** @def BUFL
 * The buffer size to use. This one is really small.
 */
#define BUFL 102

void find_box(int);

char buf[BUFL];

/** The main thing.
 * @return 0 on success, 1-255 on failure
 */
int
main(void)
{
  char box_num[10];
  char p[10];
  int box_n;
  char *end_p;
  int index = 0;

  while(1)
  {
    printf("Enter box number: ");
    fgets(box_num, sizeof(box_num), stdin);

    while(box_num[index] != '\n')
    {
      p[index] = box_num[index];
      index++;
    }
    p[index] = '\0';
    index = 0;

    box_n = strtol(p, &end_p, 10);

    if(*end_p != '\0' || box_n < 0)
    {
      fprintf(stderr, "Invalid box number.\n");
      exit(EXIT_FAILURE);
    }
    else
      find_box(box_n);
  }
  return EXIT_SUCCESS;
}

void find_box(int b_n)
{
  int off_set = 0;
  FILE *rec_file;

  printf("Searching for box #: %d\n", b_n);
  off_set = b_n * BUFL;

  if((rec_file = fopen("boxes.rec", "w+")) == NULL)
  {
    printf("Couldn't open \"boxes.rec\" for reading.\n");
    exit(EXIT_FAILURE);
  }

  fseek(rec_file, off_set, SEEK_SET);
  fgets(buf, BUFL, rec_file);
  
  if (buf[0] == NULL)
  {
    printf("This will be a new record\n");
    printf("Enter note: ");
    fgets(buf, BUFL, stdin);
  }

  fputs(buf, rec_file);
  fclose(rec_file);
  return;
}

/* vim: set et ai sts=2 sw=2: */

