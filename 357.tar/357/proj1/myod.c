/**
 * @myod.c
 * <pre> CPE 357 Winter 2011
 * -------------------
 *
 * Program acts like the Linux od(1) routine.
 * It always formats output as would "od -Ax -bc"
 *
 * Last Modified: Fri Jan 14 23:39:06 PST 2011</pre>
 * @author Luis Castillo
 * Copyright (C) 2011 Luis Castillo. All rights reserved.
 */

#include <sys/types.h>
#include <unistd.h>

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <ctype.h>

/** The main thing.
 * @param argc the number of tokens on the input line.
 * @param argv an array of tokens.
 * @return 0 on success, 1-255 on failure
 */

void od_file(void);

FILE *in_file;

int
main(int argc, char *argv[])
{
  int jvalue = 0;
  int Nvalue = 0;
  int index;
  int c;

  while((c = getopt(argc, argv, "j:N:")) != -1)
    switch(c)
    {
    case 'j':
      jvalue = (int) atoi(optarg);
      break;
    case 'N':
      Nvalue = (int) atoi(optarg);
      break;
    default:
      abort();
    }

  for(index = optind; index < argc - 1; index++)
    printf("Non-option argument %s\n", argv[index]);
 
  if((in_file = fopen(argv[argc-1], "r")) == NULL)
  {
    printf("Couldn't open \"%s\" for reading \n", argv[argc-1]);
    return EXIT_FAILURE;
  }
  
  od_file();

  return EXIT_SUCCESS;
}

void od_file()
{
  int i;
  int c;
  int byte = 0;
  int character[16];
  
  c = fgetc(in_file);
  while(c != EOF)
  {
    printf("%06x ", byte);
    for(i = 0; i < 16; i++)
    {
      character[i] = c;
      if (c == EOF)
        break;
      else
      {
        printf("%03o ",character[i]);
        c = fgetc(in_file);
      }      
      byte++;
    }
    printf("\n");
    printf("       ");
    for(i = 0; i < 16; i++)
    {
      if(character[i] == '\n')
        printf(" \\n");
      else if(character[i] == EOF)
        break;
      else
        printf("%3c ",character[i]);
    }
    printf("\n");
  }
} 

/* vim: set et ai sts=2 sw=2: */
